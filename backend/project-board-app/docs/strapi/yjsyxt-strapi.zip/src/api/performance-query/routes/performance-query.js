'use strict';

/**
 * performance-query router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::performance-query.performance-query');
