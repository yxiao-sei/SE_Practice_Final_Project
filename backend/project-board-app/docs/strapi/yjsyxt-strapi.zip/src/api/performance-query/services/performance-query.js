'use strict';

/**
 * performance-query service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::performance-query.performance-query');
