'use strict';

/**
 * performance-query controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::performance-query.performance-query');
