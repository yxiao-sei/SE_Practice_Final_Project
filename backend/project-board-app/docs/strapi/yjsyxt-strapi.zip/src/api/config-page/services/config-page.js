'use strict';

/**
 * config-page service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::config-page.config-page');
