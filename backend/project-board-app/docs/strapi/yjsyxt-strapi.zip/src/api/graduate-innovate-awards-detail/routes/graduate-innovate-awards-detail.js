'use strict';

/**
 * graduate-innovate-awards-detail router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::graduate-innovate-awards-detail.graduate-innovate-awards-detail');
