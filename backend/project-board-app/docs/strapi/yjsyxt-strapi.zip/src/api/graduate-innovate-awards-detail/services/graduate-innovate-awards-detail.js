'use strict';

/**
 * graduate-innovate-awards-detail service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::graduate-innovate-awards-detail.graduate-innovate-awards-detail');
