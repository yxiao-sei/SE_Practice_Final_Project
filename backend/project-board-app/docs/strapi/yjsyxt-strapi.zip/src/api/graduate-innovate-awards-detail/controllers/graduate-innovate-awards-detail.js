'use strict';

/**
 * graduate-innovate-awards-detail controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::graduate-innovate-awards-detail.graduate-innovate-awards-detail');
