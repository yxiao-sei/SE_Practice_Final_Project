'use strict';

/**
 * score-summary service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::score-summary.score-summary');
