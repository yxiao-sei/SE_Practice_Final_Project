'use strict';

/**
 * score-summary controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::score-summary.score-summary');
