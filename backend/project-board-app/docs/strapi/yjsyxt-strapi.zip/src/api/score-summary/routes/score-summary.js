'use strict';

/**
 * score-summary router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::score-summary.score-summary');
