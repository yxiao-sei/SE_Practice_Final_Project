'use strict';

/**
 * config-menu service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::config-menu.config-menu');
