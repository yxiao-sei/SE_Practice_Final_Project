'use strict';

/**
 * config-menu router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::config-menu.config-menu');
