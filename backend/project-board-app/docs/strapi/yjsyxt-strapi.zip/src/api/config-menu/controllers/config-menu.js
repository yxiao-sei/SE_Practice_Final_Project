'use strict';

/**
 * config-menu controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::config-menu.config-menu');
