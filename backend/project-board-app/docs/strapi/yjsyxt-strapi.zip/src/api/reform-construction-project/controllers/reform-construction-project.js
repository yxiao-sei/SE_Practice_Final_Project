'use strict';

/**
 * reform-construction-project controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::reform-construction-project.reform-construction-project');
