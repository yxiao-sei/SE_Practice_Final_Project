'use strict';

/**
 * reform-construction-project router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::reform-construction-project.reform-construction-project');
