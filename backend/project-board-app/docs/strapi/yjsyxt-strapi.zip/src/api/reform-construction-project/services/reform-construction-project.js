'use strict';

/**
 * reform-construction-project service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::reform-construction-project.reform-construction-project');
