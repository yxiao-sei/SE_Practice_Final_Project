'use strict';

/**
 * degree-audit controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::degree-audit.degree-audit');
