'use strict';

/**
 * degree-audit service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::degree-audit.degree-audit');
