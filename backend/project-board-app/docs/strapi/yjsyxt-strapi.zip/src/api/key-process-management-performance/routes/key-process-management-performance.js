'use strict';

/**
 * key-process-management-performance router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::key-process-management-performance.key-process-management-performance');
