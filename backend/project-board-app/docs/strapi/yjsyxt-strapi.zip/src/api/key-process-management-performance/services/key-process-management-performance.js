'use strict';

/**
 * key-process-management-performance service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::key-process-management-performance.key-process-management-performance');
