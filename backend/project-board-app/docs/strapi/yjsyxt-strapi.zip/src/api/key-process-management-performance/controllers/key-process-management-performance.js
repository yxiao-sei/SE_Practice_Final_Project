'use strict';

/**
 * key-process-management-performance controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::key-process-management-performance.key-process-management-performance');
