'use strict';

/**
 * approval-timeout service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::approval-timeout.approval-timeout');
