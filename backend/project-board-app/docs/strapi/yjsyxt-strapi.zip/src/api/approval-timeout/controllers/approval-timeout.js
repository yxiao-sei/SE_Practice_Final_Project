'use strict';

/**
 * approval-timeout controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::approval-timeout.approval-timeout');
