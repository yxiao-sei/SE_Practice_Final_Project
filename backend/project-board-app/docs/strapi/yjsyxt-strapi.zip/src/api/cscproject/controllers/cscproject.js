'use strict';

/**
 * cscproject controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::cscproject.cscproject');
