'use strict';

/**
 * department-international-cooperation controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::department-international-cooperation.department-international-cooperation');
