'use strict';

/**
 * department-international-cooperation service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::department-international-cooperation.department-international-cooperation');
