'use strict';

/**
 * department-international-cooperation router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::department-international-cooperation.department-international-cooperation');
