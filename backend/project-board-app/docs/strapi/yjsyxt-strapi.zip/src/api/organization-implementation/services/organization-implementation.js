'use strict';

/**
 * organization-implementation service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::organization-implementation.organization-implementation');
