'use strict';

/**
 * organization-implementation controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::organization-implementation.organization-implementation');
