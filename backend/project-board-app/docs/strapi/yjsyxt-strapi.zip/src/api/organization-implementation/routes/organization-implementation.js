'use strict';

/**
 * organization-implementation router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::organization-implementation.organization-implementation');
