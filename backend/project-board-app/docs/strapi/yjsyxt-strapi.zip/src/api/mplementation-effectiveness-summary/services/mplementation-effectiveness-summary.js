'use strict';

/**
 * mplementation-effectiveness-summary service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::mplementation-effectiveness-summary.mplementation-effectiveness-summary');
