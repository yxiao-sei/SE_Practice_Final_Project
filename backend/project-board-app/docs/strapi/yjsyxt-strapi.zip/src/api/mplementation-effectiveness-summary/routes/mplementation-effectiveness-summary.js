'use strict';

/**
 * mplementation-effectiveness-summary router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::mplementation-effectiveness-summary.mplementation-effectiveness-summary');
