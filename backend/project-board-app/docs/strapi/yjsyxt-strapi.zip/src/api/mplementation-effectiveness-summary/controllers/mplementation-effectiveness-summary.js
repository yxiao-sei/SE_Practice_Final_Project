'use strict';

/**
 * mplementation-effectiveness-summary controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::mplementation-effectiveness-summary.mplementation-effectiveness-summary');
