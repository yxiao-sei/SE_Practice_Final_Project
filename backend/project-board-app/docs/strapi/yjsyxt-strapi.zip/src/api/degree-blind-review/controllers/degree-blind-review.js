'use strict';

/**
 * degree-blind-review controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::degree-blind-review.degree-blind-review');
