'use strict';

/**
 * degree-blind-review router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::degree-blind-review.degree-blind-review');
