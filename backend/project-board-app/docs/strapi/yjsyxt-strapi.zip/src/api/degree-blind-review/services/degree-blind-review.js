'use strict';

/**
 * degree-blind-review service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::degree-blind-review.degree-blind-review');
