'use strict';

/**
 * training-model-reform-project service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::training-model-reform-project.training-model-reform-project');
