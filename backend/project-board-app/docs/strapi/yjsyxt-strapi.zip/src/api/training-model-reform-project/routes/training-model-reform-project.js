'use strict';

/**
 * training-model-reform-project router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::training-model-reform-project.training-model-reform-project');
