'use strict';

/**
 * training-model-reform-project controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::training-model-reform-project.training-model-reform-project');
