'use strict';

/**
 * affirm-competition-award controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::affirm-competition-award.affirm-competition-award');
