'use strict';

/**
 * affirm-competition-award service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::affirm-competition-award.affirm-competition-award');
