'use strict';

/**
 * affirm-competition-award router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::affirm-competition-award.affirm-competition-award');
