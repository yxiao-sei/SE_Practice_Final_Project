'use strict';

/**
 * degree-duplicate-checking controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::degree-duplicate-checking.degree-duplicate-checking');
