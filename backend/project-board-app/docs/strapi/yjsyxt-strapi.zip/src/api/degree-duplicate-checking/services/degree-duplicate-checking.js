'use strict';

/**
 * degree-duplicate-checking service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::degree-duplicate-checking.degree-duplicate-checking');
