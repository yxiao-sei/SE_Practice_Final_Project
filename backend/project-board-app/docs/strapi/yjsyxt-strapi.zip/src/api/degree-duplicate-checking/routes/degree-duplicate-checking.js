'use strict';

/**
 * degree-duplicate-checking router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::degree-duplicate-checking.degree-duplicate-checking');
