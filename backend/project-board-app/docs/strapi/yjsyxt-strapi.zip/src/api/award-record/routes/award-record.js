'use strict';

/**
 * award-record router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::award-record.award-record');
