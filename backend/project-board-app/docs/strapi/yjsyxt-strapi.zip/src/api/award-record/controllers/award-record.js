'use strict';

/**
 * award-record controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::award-record.award-record');
