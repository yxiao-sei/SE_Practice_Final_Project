'use strict';

/**
 * teaching-construction-training-reform-result controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::teaching-construction-training-reform-result.teaching-construction-training-reform-result');
