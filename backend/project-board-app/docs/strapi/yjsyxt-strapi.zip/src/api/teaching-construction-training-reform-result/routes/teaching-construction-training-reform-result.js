'use strict';

/**
 * teaching-construction-training-reform-result router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::teaching-construction-training-reform-result.teaching-construction-training-reform-result');
