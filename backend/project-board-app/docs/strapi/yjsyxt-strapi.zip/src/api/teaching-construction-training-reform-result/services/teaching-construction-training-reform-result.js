'use strict';

/**
 * teaching-construction-training-reform-result service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::teaching-construction-training-reform-result.teaching-construction-training-reform-result');
