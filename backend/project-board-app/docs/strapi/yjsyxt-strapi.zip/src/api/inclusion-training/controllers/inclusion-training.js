'use strict';

/**
 * inclusion-training controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::inclusion-training.inclusion-training');
