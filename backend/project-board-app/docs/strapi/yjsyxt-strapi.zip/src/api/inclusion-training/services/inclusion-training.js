'use strict';

/**
 * inclusion-training service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::inclusion-training.inclusion-training');
