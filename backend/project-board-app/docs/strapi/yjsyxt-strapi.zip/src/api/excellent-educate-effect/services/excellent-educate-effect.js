'use strict';

/**
 * excellent-educate-effect service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::excellent-educate-effect.excellent-educate-effect');
