'use strict';

/**
 * excellent-educate-effect controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::excellent-educate-effect.excellent-educate-effect');
