'use strict';

/**
 * excellent-educate-effect router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::excellent-educate-effect.excellent-educate-effect');
