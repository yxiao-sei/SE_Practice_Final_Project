'use strict';

/**
 * excellent-doctoral-academic-innovation-project controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::excellent-doctoral-academic-innovation-project.excellent-doctoral-academic-innovation-project');
