'use strict';

/**
 * excellent-doctoral-academic-innovation-project service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::excellent-doctoral-academic-innovation-project.excellent-doctoral-academic-innovation-project');
