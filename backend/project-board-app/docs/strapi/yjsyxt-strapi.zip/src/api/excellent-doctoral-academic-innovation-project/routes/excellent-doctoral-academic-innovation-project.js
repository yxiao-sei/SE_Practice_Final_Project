'use strict';

/**
 * excellent-doctoral-academic-innovation-project router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::excellent-doctoral-academic-innovation-project.excellent-doctoral-academic-innovation-project');
