'use strict';

/**
 * enrollment-promotion controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::enrollment-promotion.enrollment-promotion');
