'use strict';

/**
 * enrollment-promotion service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::enrollment-promotion.enrollment-promotion');
