'use strict';

/**
 * graduation-rate-by-term router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::graduation-rate-by-term.graduation-rate-by-term');
