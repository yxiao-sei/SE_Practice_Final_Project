'use strict';

/**
 * graduation-rate-by-term controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::graduation-rate-by-term.graduation-rate-by-term');
