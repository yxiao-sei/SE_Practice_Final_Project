'use strict';

/**
 * graduation-rate-by-term service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::graduation-rate-by-term.graduation-rate-by-term');
