'use strict';

/**
 * innovation-practice-competition-detail controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::innovation-practice-competition-detail.innovation-practice-competition-detail');
