'use strict';

/**
 * innovation-practice-competition-detail service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::innovation-practice-competition-detail.innovation-practice-competition-detail');
