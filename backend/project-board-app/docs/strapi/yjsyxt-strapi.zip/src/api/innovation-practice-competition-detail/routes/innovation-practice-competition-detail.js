'use strict';

/**
 * innovation-practice-competition-detail router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::innovation-practice-competition-detail.innovation-practice-competition-detail');
