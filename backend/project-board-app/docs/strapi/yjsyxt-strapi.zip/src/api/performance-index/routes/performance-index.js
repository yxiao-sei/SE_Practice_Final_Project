'use strict';

/**
 * performance-index router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::performance-index.performance-index');
