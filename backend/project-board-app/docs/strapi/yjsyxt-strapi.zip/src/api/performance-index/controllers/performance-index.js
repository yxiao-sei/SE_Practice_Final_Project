'use strict';

/**
 * performance-index controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::performance-index.performance-index');
