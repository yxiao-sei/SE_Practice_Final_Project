'use strict';

/**
 * conference-visitor router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::conference-visitor.conference-visitor');
