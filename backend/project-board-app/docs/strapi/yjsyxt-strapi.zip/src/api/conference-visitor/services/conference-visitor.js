'use strict';

/**
 * conference-visitor service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::conference-visitor.conference-visitor');
