'use strict';

/**
 * conference-visitor controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::conference-visitor.conference-visitor');
