'use strict';

/**
 * custom-userdetail controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::custom-userdetail.custom-userdetail');
