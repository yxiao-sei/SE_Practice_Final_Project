'use strict';

/**
 * custom-userdetail service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::custom-userdetail.custom-userdetail');
