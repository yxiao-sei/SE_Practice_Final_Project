'use strict';

/**
 * graduate-degree-award service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::graduate-degree-award.graduate-degree-award');
