'use strict';

/**
 * graduate-degree-award router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::graduate-degree-award.graduate-degree-award');
