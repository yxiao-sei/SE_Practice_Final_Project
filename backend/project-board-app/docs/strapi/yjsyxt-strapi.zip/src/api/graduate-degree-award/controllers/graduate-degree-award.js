'use strict';

/**
 * graduate-degree-award controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::graduate-degree-award.graduate-degree-award');
