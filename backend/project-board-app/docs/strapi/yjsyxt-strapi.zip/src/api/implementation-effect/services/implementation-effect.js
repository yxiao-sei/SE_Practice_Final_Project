'use strict';

/**
 * implementation-effect service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::implementation-effect.implementation-effect');
