'use strict';

/**
 * implementation-effect router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::implementation-effect.implementation-effect');
