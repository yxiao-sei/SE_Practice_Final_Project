'use strict';

/**
 * implementation-effect controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::implementation-effect.implementation-effect');
