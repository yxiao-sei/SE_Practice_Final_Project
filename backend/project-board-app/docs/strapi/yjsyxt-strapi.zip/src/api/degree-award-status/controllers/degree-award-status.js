'use strict';

/**
 * degree-award-status controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::degree-award-status.degree-award-status');
