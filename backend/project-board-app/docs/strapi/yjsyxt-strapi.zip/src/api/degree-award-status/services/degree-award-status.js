'use strict';

/**
 * degree-award-status service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::degree-award-status.degree-award-status');
