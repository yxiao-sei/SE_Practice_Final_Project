'use strict';

/**
 * degree-award-status router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::degree-award-status.degree-award-status');
