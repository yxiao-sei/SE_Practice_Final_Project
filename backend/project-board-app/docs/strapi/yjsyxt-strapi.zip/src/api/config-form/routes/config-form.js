'use strict';

/**
 * config-form router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::config-form.config-form');
