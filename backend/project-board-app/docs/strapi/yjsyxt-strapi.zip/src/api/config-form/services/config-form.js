'use strict';

/**
 * config-form service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::config-form.config-form');
