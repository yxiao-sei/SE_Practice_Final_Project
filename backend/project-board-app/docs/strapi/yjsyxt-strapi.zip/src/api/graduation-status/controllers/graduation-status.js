'use strict';

/**
 * graduation-status controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::graduation-status.graduation-status');
