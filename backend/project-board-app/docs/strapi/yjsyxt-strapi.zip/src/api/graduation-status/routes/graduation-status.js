'use strict';

/**
 * graduation-status router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::graduation-status.graduation-status');
