'use strict';

/**
 * department controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::department.department');
