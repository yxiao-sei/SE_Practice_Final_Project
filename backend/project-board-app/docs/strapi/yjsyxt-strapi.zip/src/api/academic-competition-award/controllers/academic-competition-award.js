'use strict';

/**
 * academic-competition-award controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::academic-competition-award.academic-competition-award');
