'use strict';

/**
 * academic-competition-award service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::academic-competition-award.academic-competition-award');
