'use strict';

/**
 * academic-competition-award router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::academic-competition-award.academic-competition-award');
