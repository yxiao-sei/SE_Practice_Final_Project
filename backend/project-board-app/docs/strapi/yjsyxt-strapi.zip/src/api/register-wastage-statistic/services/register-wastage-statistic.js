'use strict';

/**
 * register-wastage-statistic service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::register-wastage-statistic.register-wastage-statistic');
