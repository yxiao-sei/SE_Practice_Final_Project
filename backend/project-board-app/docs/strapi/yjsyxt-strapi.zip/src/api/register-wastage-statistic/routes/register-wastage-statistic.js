'use strict';

/**
 * register-wastage-statistic router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::register-wastage-statistic.register-wastage-statistic');
