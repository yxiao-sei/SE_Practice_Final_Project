'use strict';

/**
 * register-wastage-statistic controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::register-wastage-statistic.register-wastage-statistic');
