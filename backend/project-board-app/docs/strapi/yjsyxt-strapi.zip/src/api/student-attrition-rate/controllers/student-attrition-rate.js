'use strict';

/**
 * student-attrition-rate controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::student-attrition-rate.student-attrition-rate');
