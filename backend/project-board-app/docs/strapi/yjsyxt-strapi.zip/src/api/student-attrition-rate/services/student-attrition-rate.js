'use strict';

/**
 * student-attrition-rate service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::student-attrition-rate.student-attrition-rate');
