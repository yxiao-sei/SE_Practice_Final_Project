'use strict';

/**
 * teaching-achievement controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::teaching-achievement.teaching-achievement');
