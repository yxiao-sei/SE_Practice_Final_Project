'use strict';

/**
 * teaching-achievement service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::teaching-achievement.teaching-achievement');
