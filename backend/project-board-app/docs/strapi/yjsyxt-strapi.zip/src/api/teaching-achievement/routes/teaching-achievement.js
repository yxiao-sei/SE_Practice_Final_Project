'use strict';

/**
 * teaching-achievement router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::teaching-achievement.teaching-achievement');
