'use strict';

/**
 * foreign-language-competition router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::foreign-language-competition.foreign-language-competition');
