'use strict';

/**
 * foreign-language-competition service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::foreign-language-competition.foreign-language-competition');
