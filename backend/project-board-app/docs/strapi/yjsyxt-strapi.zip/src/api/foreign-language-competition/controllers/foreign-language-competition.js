'use strict';

/**
 * foreign-language-competition controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::foreign-language-competition.foreign-language-competition');
