'use strict';

/**
 * recognition-record controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::recognition-record.recognition-record');
