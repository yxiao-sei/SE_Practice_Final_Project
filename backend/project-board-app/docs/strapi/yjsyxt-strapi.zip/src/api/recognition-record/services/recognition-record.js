'use strict';

/**
 * recognition-record service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::recognition-record.recognition-record');
