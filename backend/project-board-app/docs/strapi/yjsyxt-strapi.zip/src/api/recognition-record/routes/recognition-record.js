'use strict';

/**
 * recognition-record router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::recognition-record.recognition-record');
