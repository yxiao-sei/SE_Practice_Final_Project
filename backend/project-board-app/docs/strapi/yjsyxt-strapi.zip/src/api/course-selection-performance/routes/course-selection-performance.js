'use strict';

/**
 * course-selection-performance router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::course-selection-performance.course-selection-performance');
