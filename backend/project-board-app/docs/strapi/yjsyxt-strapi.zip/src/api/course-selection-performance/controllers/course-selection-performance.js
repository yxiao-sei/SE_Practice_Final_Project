'use strict';

/**
 * course-selection-performance controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::course-selection-performance.course-selection-performance');
