'use strict';

/**
 * course-selection-performance service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::course-selection-performance.course-selection-performance');
