'use strict';

/**
 * graduate-course-ideology-construction controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::graduate-course-ideology-construction.graduate-course-ideology-construction');
