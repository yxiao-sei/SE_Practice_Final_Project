'use strict';

/**
 * graduate-course-ideology-construction router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::graduate-course-ideology-construction.graduate-course-ideology-construction');
