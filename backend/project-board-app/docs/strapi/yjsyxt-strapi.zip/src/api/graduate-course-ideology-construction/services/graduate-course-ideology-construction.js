'use strict';

/**
 * graduate-course-ideology-construction service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::graduate-course-ideology-construction.graduate-course-ideology-construction');
