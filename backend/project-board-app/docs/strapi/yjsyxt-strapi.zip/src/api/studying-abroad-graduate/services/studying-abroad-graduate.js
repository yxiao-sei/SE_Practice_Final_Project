'use strict';

/**
 * studying-abroad-graduate service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::studying-abroad-graduate.studying-abroad-graduate');
