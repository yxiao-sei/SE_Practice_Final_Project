'use strict';

/**
 * studying-abroad-graduate controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::studying-abroad-graduate.studying-abroad-graduate');
