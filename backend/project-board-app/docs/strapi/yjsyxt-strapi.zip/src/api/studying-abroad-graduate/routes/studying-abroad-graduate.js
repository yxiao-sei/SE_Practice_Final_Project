'use strict';

/**
 * studying-abroad-graduate router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::studying-abroad-graduate.studying-abroad-graduate');
