'use strict';

/**
 * performance-setting controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::performance-setting.performance-setting');
