'use strict';

/**
 * performance-setting service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::performance-setting.performance-setting');
