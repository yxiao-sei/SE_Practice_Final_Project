'use strict';

/**
 * performance-setting router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::performance-setting.performance-setting');
