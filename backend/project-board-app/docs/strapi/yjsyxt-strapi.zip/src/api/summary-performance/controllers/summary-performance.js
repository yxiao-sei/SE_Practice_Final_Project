'use strict';

/**
 * summary-performance controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::summary-performance.summary-performance');
