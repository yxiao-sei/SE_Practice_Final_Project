'use strict';

/**
 * summary-performance service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::summary-performance.summary-performance');
