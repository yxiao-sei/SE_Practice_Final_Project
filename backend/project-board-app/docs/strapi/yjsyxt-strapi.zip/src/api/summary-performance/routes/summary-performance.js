'use strict';

/**
 * summary-performance router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::summary-performance.summary-performance');
