'use strict';

/**
 * enrollment-rate controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::enrollment-rate.enrollment-rate');
