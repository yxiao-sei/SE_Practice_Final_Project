'use strict';

/**
 * enrollment-rate service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::enrollment-rate.enrollment-rate');
